class PrimRecFun(object):
	
	def __repr__(self):
		return '{}({})'.format(self.__class__.__name__, ",".join(map(repr, self.arguments())))
		
	def __call__(self,*args):
		assert len(args)==self.arity
		return self.call(*args)
		
class Z(PrimRecFun):
	arity=0
	
	def arguments(self):
		return ()
		
	def call(self):
		return 0
		
class S(PrimRecFun):
	arity=1
	
	def arguments(Self):
		return ()
		
	def call(self, obj):
		return obj + 1

class P(PrimRecFun):
	
	def __init__(self, n, i):
		assert n>0
		assert 0<i<=n
		self.i=i
		self.n=n
		self.arity=n
		
	def arguments(self):
		return (self.n, self.i)
		
	def call(self, *args):
		return args[self.i-1]
		
class C(PrimRecFun):

	def __init__(self, g, h):
		assert len(h)==g.arity
		for function in h:
			assert h[0].arity==function.arity
		self._g=g
		self._h=h
		self.arity=h[0].arity
		
	def arguments(self):
		return [self._g] + [self._h]
	
	def call(self, *x):
		return self._g(*(h(*x) for h in self._h))	
	
class R(PrimRecFun):

	def __init__(self, g, h):
		assert h.arity == g.arity + 2
		self._g=g
		self._h=h
		self.arity=g.arity+1
		
	def arguments(self):
		return [self._g, self._h]
		
	def call(self, *x):
		y=self._g(*x[:-1])
		for i in range(x[-1]):
			y=self._h(*x[:-1]+(i,)+(y,))
		return y