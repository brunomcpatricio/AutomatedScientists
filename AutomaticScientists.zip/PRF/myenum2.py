from classesprf import PrimRecFun 
from classesprf import Z 
from classesprf import S
from classesprf import P 
from classesprf import C 
from classesprf import R  

def Functions(size,ar):
	if size <= 0:
		pass
	elif size == 1:
		if ar == 0: yield Z()
		elif ar == 1: yield S()
		for i in range(1, ar+1): yield P(ar,i)
	else:
		for composition in Compositions(size,ar):
			yield composition
		for recursionion in Recursions(size,ar):
			yield recursionion

def Functions_With_Maxsize(size,ar):
    for subsize in range(1, size + 1):
        for function in Functions(subsize,ar):
            yield function, size - subsize
			

def Composition_Function_Lists(length, size, ar):
	if length == 0:
		if size == 0:
			yield []
		else:
			pass
	else:
		for function, remaining_size in Functions_With_Maxsize(size,ar):
			for sublist in Composition_Function_Lists(length - 1, remaining_size, ar):
				if not inList(function,sublist):
					yield [function] + sublist

def Compositions(size,ar):
	for i in range(1,size-1):
		for j in range(1,size-1):
			for function_list in Composition_Function_Lists(i,j,ar):
				for g in Functions(size - j - 1,i): yield C(g, function_list)
				
def Recursions(size,ar):
    for function, size_2 in Functions_With_Maxsize(size - 1, ar - 1):
        for function2 in Functions(size_2, ar + 1):
            yield R(function, function2)

def same(obj1,obj2):
	if type(obj1)!=type(obj2) : return False
	else:
		if isinstance(obj1,S) or isinstance(obj1,Z): return True
		elif isinstance(obj1,P):
			if obj1.i != obj2.i or obj1.n != obj2.n: return False
			else: return True
		elif isinstance(obj1,R):
			if same(obj1._g,obj2._g) and same(obj1._h,obj2._h): return True
			else: return False
		elif isinstance(obj1,C):
			if same(obj1._g,obj2._g) and len(obj1._h)==len(obj2._h) and (same(obj1._h[i],obj2._h[i]) for i in range(len(obj1._h))): return True
			else: return False
		
def inList(obj,objl):
	b=False
	for obja in objl:
		b=same(obj,obja)
		if b==True: break
	return b 
	
