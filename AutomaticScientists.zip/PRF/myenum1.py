from classesprf import PrimRecFun 
from classesprf import Z 
from classesprf import S
from classesprf import P 
from classesprf import C 
from classesprf import R  
import time

def Functions(size):
    if size <= 0:
        pass
    elif size == 1:
        yield Z();
        yield S();
        for i in range(1, 4):
            for j in range(1, i+1):
                yield P(i,j)
    else:
        for composition in Compositions(size):
            yield composition
        for recursionion in Recursions(size):
            yield recursionion

def Functions_With_Maxsize(size):
    for subsize in range(1, size + 1):
        for function in Functions(subsize):
            yield function, size - subsize
			

def Composition_Function_Lists(length, size, arity = None):
    if length == 0:
        if size == 0:
            yield []
        else:
            pass
    else:        
        for function, remaining_size in Functions_With_Maxsize(size):
            if arity is None or arity == function.arity:
                for sublist in Composition_Function_Lists(length - 1, remaining_size, function.arity): yield [function] + sublist

def Compositions(size):
	for g, after_g_size in Functions_With_Maxsize(size - 1):
		if g.arity > 0:
			for function_list in Composition_Function_Lists(g.arity, after_g_size): yield C(g, function_list)
			
def Recursions(size):
    for function, size_2 in Functions_With_Maxsize(size - 1):
        for function2 in Functions(size_2):
            if function2.arity == function.arity + 2:
                yield R(function, function2)
