In folder "PRF" are the files relative to the search performed in the set of primitive recursive functions. These files include:

 - a file "classesprf.txt" with the definition of the classes that represent the functions that are used to contruct all 
 primitive recursive functions;

 - files "myenum1.py" and "myenum2.py" with two different ways of listing the primitive recursive functions;

 - files "search1.py" and "search2.py" that using the two enumeration Python files, respectively, will perform the 
 search of the function we want and, when it finds it, will output a .txt file (write.txt) with the code that computes it.


In folder "El" are the files relative to the search performedin the set of elementary functions. These files include:

 - a file "classesel.txt" with the definition of the classes that represent the functions that are used to contruct all 
 elementary functions;

 - file "myenumel.py" with the listing of the elementary functions;

 - file "searchel.py"that using the enumeration Python file will perform the search of the function we want and, when it
 finds it, will output a .txt file (write.txt) with the code that computes it.



The program will work the following way (on Windows 10 operating system):

 1. Double click on the file upon which you want to perform the search (search1.py, search2.py or searchel.py). This will
    open a pop-up interactive window and an executable black window where the search procedure is going to be presented;

 2. In the field identified as "Input" insert the values of the input for the function you want to find. Separate the elements
    of each tuple with commas (",") and the different tuples with one blank space (" "); do not write parenthesis or any other
    symbols.

 3. In the field identified as "Output" insert the values of the output for the function you want to find, in the same respective
    order of the input elements. Separate each value with one blank space (" ").

 4. After inserting all the values, press the button "Search". Once the procedure finds a description that explains the relation
    between the input and output values, it will print it in the field identified as "Description" and it will print the Python
    code relative to that description in a .txt file called "code.txt".

 5. For testing that function for other values, delete the "Input" field and write other input values (as much as you want), with 
    the same rules as the ones written in 2. After, press the button "Test". The results of applying the found function to the 
    input values will appear in the field "Output" in the correct order.

 6. Do this process the number of times you want.


Remark: in each file search1.py, search2.py and searchel.py there exists a commented line of code "#print(i, fun)". That line has
the purpose of printing the current description being analyzed and its size. You can uncomment this line (just open these files in 
an editor and delete the character "#", save the file and execute the procedure above) to observe the progress of the search 
procedure with the listing of functions being printed (for example, to see if it gets 'stuck' in a description while verifying if 
it explains correctlythe inserted values). We added this line of code because through some of our tests the verification of some 
functions would not terminate, specially those with big input values. However, this will slow down the procedure a lot.