from classesel import ElFunc
from classesel import EZ 
from classesel import ES 
from classesel import EP 
from classesel import EC 
from classesel import EA 
from classesel import ET
from classesel import ED
from classesel import EM
from classesel import EBS
from classesel import EBP
from myenumel import ElFunctions
from myenumel import ElFunctions_With_Maxsize
from myenumel import ElCompositions
from myenumel import ElComposition_Function_Lists
from myenumel import ElBoundedSums
from myenumel import ElBoundedProds
import tkinter
from tkinter import Tk
from tkinter import Label
from tkinter import Entry
from tkinter import Button
from tkinter import W
from tkinter import mainloop
import itertools as it
import time  
import sympy as sym
import threading

indcount=1
descr = None

def Search():
	if e1.get()=="": print("Insert input values")
	elif e2.get()=="": print("Insert output values")
	else:
		start = time.time()
		print("begins")
		inp=[]
		for k in range(len(e1.get().split())):
			inp.append(tuple(map(int,tuple(e1.get().split(' ')[k].split(',')))))
		out=list(map(int,e2.get().split()))
		l=len(inp)
		a=len(inp[0])
		print("input list:", inp)
		print("output list:", out)
		print("begin search")
		for i in it.count(1):
			print("length of description: ", i)
			funtime = time.time()
			for fun in ElFunctions(i,a):
				t = True
				#print(i,fun)
				for j in range(l):
					t = t and fun(*inp[j])==out[j]
					if t==False:
						break
				if t:
					res = fun
					break
			if t:
				break
		print("function found!")
		end = time.time()
		print(res)
		print(end-start)
		e3.delete(0,tkinter.END)
		e3.insert(0,res)
		desc=res
		file = open("code.txt","w+")
		file.truncate(0)
		listvars = sym.symbols('a0:100')
		file.write("def funct(x):")
		file.write('\n'+'\t'+"a0 = x")

		def printcode(exp,lv):
			global indcount;
			y = lv[0]
			lv = lv[1:]
			if isinstance(exp,EZ):
				y=lv[0]
				lv=lv[1:]
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("{} = 0".format(y))
			elif isinstance(exp,ES):
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("if type({}) != int: {} = {}[0] + 1".format(y,lv[0],y))
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("else: {} = {} + 1".format(lv[0],y))
				y=lv[0]	
				lv=lv[1:]			
			elif isinstance(exp,EP):
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("if type({}) != int: {} = {}[{}]".format(y,lv[0],y,exp.arguments()[1]-1))
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("else: {} = tuple([{}])[{}]".format(lv[0],y,exp.arguments()[1]-1))
				y=lv[0]	
				lv=lv[1:]
			elif isinstance(exp,EA):
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("{} = {}[0] + {}[1]".format(lv[0],y,y))
				y=lv[0]	
				lv=lv[1:]
			elif isinstance(exp,ET):
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("{} = {}[0] * {}[1]".format(lv[0],y,y))
				y=lv[0]	
				lv=lv[1:]
			elif isinstance(exp,ED):
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("if {}[0] == 0: {} = 0".format(y,lv[0]))
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("else: {} = {}[1] // {}[0]".format(lv[0],y,y))
				y=lv[0]	
				lv=lv[1:]
			elif isinstance(exp,EM):
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("if {}[0] > {}[1]: {} = {}[0] - {}[1]".format(y,y,lv[0],y,y))
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("else: {} = 0".format(lv[0]))
				y=lv[0]	
				lv=lv[1:]
			elif isinstance(exp,EC):
				l=[]
				for arg in exp.arguments()[1]:
					m=printcode(arg,(y,)+lv)
					l.append(m[0])
					lv=m[1]	
				if len(l)>1:
					y=m[0]
					lv=m[1]
					file.write('\n')
					for id in range(indcount):
						file.write('\t')
					file.write("{} = tuple({})".format(lv[0],l))
				else: lv= (l[0],)+lv
				y=lv[0]
				lv=lv[1:]
				n=printcode(exp.arguments()[0],(y,)+lv)
				y=n[0]
				lv=n[1]
			elif isinstance(exp,EBS):
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("if type({})==int: {}=({},)".format(y,y,y))
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("{} = {}[:-1]".format(lv[0],y))
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("{} = 0".format(lv[1],y))
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("for i in range({}[-1]):".format(y))
				indcount=indcount+1
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("{} = ({}+(i,))".format(lv[2],lv[0]))
				y=lv[1]
				lv=lv[2:]
				p=printcode(exp.arguments()[0],lv)
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write('{} = {} + {}'.format(y,y,p[0]))
				indcount = indcount-1
			elif isinstance(exp,EBP):
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("if type({})==int: {}=({},)".format(y,y,y))
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("{} = {}[:-1]".format(lv[0],y))
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("{} = 1".format(lv[1],y))
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("for i in range({}[-1]):".format(y))
				indcount=indcount+1
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write("{} = ({}+(i,))".format(lv[2],lv[0]))
				y=lv[1]
				lv=lv[2:]
				q=printcode(exp.arguments()[0],lv)
				file.write('\n')
				for id in range(indcount):
					file.write('\t')
				file.write('{} = {} * {}'.format(y,y,q[0]))
				indcount = indcount-1	
			return [y, lv]
		r=printcode(desc,listvars)
		file.write('\n'+'\t'+"return {}".format(r[0]))	
		file.close()
		global descr
		descr = res
		return descr

def Test():
	inp=[]
	for k in range(len(e1.get().split())):
		inp.append(tuple(map(int,tuple(e1.get().split(' ')[k].split(',')))))
	out=[]
	if descr == None: print("First perform the search.")
	else:
		for tup in inp: 
			out.append(descr(*tup))
		e2.delete(0,tkinter.END)
		e2.insert(0,out)

master = Tk()
Label(master, text="Input").grid(row=0)
Label(master, text="Output").grid(row=1)
Label(master, text="Description").grid(row=2)

e1 = Entry(master)
e2 = Entry(master)
e3 = Entry(master)

e1.grid(row=0, column=1)
e2.grid(row=1, column=1)
e3.grid(row=2, column=1)

b1=Button(master, text='Search', command=Search).grid(row=3, column=1, sticky=W, pady=4)
b2=Button(master, text='Test', command=Test).grid(row=4, column=1, sticky=W, pady=4)

mainloop( )