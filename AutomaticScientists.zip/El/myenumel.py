from classesel import ElFunc
from classesel import EZ 
from classesel import ES
from classesel import EP
from classesel import EC
from classesel import EA
from classesel import ET
from classesel import EM
from classesel import ED
from classesel import EBS
from classesel import EBP  

def ElFunctions(size,ar):
	if size <= 0:
		pass
	elif size == 1:
		if ar == 0: yield EZ()
		elif ar == 1: yield ES()
		elif ar == 2: yield ET(); yield EM(); yield EA(); yield ED()
		for i in range(1, ar+1): yield EP(ar,i)
	else:
		for composition in ElCompositions(size,ar):
			yield composition
		for boundedsum in ElBoundedSums(size,ar):
			yield boundedsum
		for boundedprod in ElBoundedProds(size,ar):
			yield boundedprod			

def ElFunctions_With_Maxsize(size,ar):
    for subsize in range(1, size + 1):
        for function in ElFunctions(subsize,ar):
            yield function, size - subsize
			
def ElComposition_Function_Lists(length, size, ar):
	if length == 0:
		if size == 0:
			yield []
		else:
			pass
	else:
		for function, remaining_size in ElFunctions_With_Maxsize(size,ar):
			for sublist in ElComposition_Function_Lists(length - 1, remaining_size, ar):
				yield [function] + sublist
					
def ElCompositions(size,ar):
	for i in range(1,size-1):
		for j in range(1,size-1):
			for function_list in ElComposition_Function_Lists(i,j,ar):
				for g in ElFunctions(size - j - 1,i): yield EC(g, function_list)
				
def ElBoundedSums(size,ar):
	if ar == 0: pass
	else:
		for f in ElFunctions(size-1,ar):
			yield EBS(f)
		
def ElBoundedProds(size,ar):
	if ar == 0: pass
	else:
		for fun in ElFunctions(size-1,ar):
			yield EBP(fun)