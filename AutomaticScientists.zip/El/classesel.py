import math

class ElFunc(object):
	
	def __repr__(self):
		return '{}({})'.format(self.__class__.__name__, ",".join(map(repr, self.arguments())))
		
	def __call__(self,*args):
		assert len(args)==self.arity
		return self.call(*args)
		
class EZ(ElFunc):
	arity=0
	
	def arguments(self):
		return ()
		
	def call(self):
		return 0
		
class ES(ElFunc):
	arity=1
	
	def arguments(self):
		return ()
		
	def call(self, obj):
		return obj + 1
		
class EP(ElFunc):
	
	def __init__(self, n, i):
		assert n>0
		assert 0<i<=n
		self.i=i
		self.n=n
		self.arity=n
		
	def arguments(self):
		return (self.n, self.i)
		
	def call(self, *args):
		return args[self.i-1]
		
class EC(ElFunc):

	def __init__(self, g, h):
		assert len(h)==g.arity
		for function in h:
			assert h[0].arity==function.arity
		self._g=g
		self._h=h
		self.arity=h[0].arity
		
	def arguments(self):
		return [self._g] + [self._h]
	
	def call(self, *x):
		return self._g(*(h(*x) for h in self._h))

class EA(ElFunc):
	arity = 2
	
	def arguments(self):
		return ()
	
	def call(self,*args):
		return args[0]+args[1]
		
class EM(ElFunc):
	arity = 2
	
	def arguments(self):
		return()
		
	def call(self,*args):
		if args[0] > args[1]: return args[0] - args[1]
		else: return 0
		
class ET(ElFunc):
	arity = 2
	
	def arguments(self):
		return ()
		
	def call(self,*args):
		return args[0]*args[1]
		
class ED(ElFunc):
	arity = 2
	
	def arguments(self):
		return ()
		
	def call(self,*args):
		if args[0]!=0: return args[1] // args[0]
		else: return 0
		
class EBS(ElFunc):
	
	def __init__(self, g):
		assert g.arity > 0
		self._g=g
		self.arity=g.arity
		
	def arguments(self):
		return [self._g]
		
	def call(self,*args):
		d=0
		for i in range(args[-1]):
			d=d+self._g(*args[:-1]+(i,))
		return d
		
class EBP(ElFunc):
	
	def __init__(self, g):
		assert g.arity > 0
		self._g=g
		self.arity=g.arity
		
	def arguments(self):
		return [self._g]
		
	def call(self,*args):
		d=1
		for i in range(args[-1]):
			d=d*self._g(*args[:-1]+(i,))
		return d

